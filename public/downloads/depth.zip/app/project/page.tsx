import Template from '../kits/depth/Template';
export default function Page() { return <Template page="project" basePath="" />; }
