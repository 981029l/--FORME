import Template from '../kits/hotel/Template';
export default function Page() { return <Template page="project" basePath="" />; }
