# software 模板修改规则

先阅读 README.md、DESIGN.md 和 app/kits/software/content.ts。

- 修改内容优先使用 content.ts，保持已定义的图片比例与路径。
- 复用现有组件、布局、主题变量；新增页面先参照 project 与 about 页面。
- CSS 作用域保持 .kit-software，不得覆盖全局或其他品牌样式。
- 不随意引入新颜色、字体、圆角、阴影、组件库或动效依赖。需要变更时说明原因。
- 样式修改后检查手机、桌面、中文长标题、键盘焦点与减少动态效果。
- 运行 npm run build，验证页面导航与联系按钮；新功能同步更新 README。
- 规范是设计参照，自动化截图只能发现变化，审美仍需人工判断。
