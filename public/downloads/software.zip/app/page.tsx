import Template from './kits/software/Template';
export default function Page() { return <Template page="home" basePath="" />; }
