import Template from '../kits/doodle/Template';
export default function Page() { return <Template page="project" basePath="" />; }
