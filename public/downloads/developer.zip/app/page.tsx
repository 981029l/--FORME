import Template from './kits/developer/Template';
export default function Page() { return <Template page="home" basePath="" />; }
