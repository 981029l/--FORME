import Template from '../kits/education/Template';
export default function Page() { return <Template page="about" basePath="" />; }
