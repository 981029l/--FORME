import Template from './kits/cinema/Template';
export default function Page() { return <Template page="home" basePath="" />; }
