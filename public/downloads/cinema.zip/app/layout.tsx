import './base.css';
import './kits/cinema/theme.css';
export const metadata = { title: 'FORME cinema', description: '形集创意作品模板' };
export default function Layout({children}:{children:React.ReactNode}) { return <html lang="zh-CN"><body>{children}</body></html>; }
