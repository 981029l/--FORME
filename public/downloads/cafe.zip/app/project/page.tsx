import Template from '../kits/cafe/Template';
export default function Page() { return <Template page="project" basePath="" />; }
