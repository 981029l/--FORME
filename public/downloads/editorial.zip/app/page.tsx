import Template from './kits/editorial/Template';
export default function Page() { return <Template page="home" basePath="" />; }
