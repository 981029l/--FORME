import './base.css';
import './kits/editorial/theme.css';
export const metadata = { title: 'FORME editorial', description: '形集创意作品模板' };
export default function Layout({children}:{children:React.ReactNode}) { return <html lang="zh-CN"><body>{children}</body></html>; }
