import Template from '../kits/architecture/Template';
export default function Page() { return <Template page="about" basePath="" />; }
