import Template from '../kits/botanical/Template';
export default function Page() { return <Template page="project" basePath="" />; }
