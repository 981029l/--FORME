import Template from '../kits/wellness/Template';
export default function Page() { return <Template page="about" basePath="" />; }
