import Template from '../kits/experimental/Template';
export default function Page() { return <Template page="about" basePath="" />; }
