import Template from '../kits/dashboard/Template';
export default function Page() { return <Template page="about" basePath="" />; }
