# FORME dashboard 完整网站模板

## 运行

需要 Node.js 20.9 或更高版本。解压后在本目录运行：

```sh
npm install
npm run dev
```

打开终端显示的 localhost 地址。发布前运行 `npm run build`，随后可运行 `npm start`。

## 文件与页面

- app/page.tsx：首页。
- app/project/page.tsx：完整项目页。
- app/about/page.tsx：关于与联系。
- app/kits/dashboard/content.ts：文案、项目资料与图片配置。
- app/kits/dashboard/Template.tsx：页面组件，和形集在线预览使用同一源码。
- app/kits/dashboard/theme.css：本套模板主题与响应式样式。
- DESIGN.md：设计规则。AGENTS.md：AI 修改约束。SOURCES.md：素材来源。

## 修改方法

先替换 content.ts 的演示资料和 public/assets 中的图片。让 AI 阅读 DESIGN.md、AGENTS.md，再复用现有组件扩展页面。新增详情页可复制 app/project/page.tsx 的路由结构，并给 Template 的内容配置扩展项目参数。不要把同一个样式改动散落到多个页面。

## 说明

当前版本供免费下载与本地试用。演示品牌与项目为虚构示例；联系按钮仅复制标记为示例的地址，不发送信息。图片与字体保留各自许可。正式公开发布前，由维护者确定模板授权条款。

源码只包含本套模板，不依赖形集平台，也没有平台账号、远程 API 或追踪脚本。
