import Template from '../kits/museum/Template';
export default function Page() { return <Template page="about" basePath="" />; }
