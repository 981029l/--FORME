import Template from '../kits/playful/Template';
export default function Page() { return <Template page="project" basePath="" />; }
