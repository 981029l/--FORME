import Template from './kits/product/Template';
export default function Page() { return <Template page="home" basePath="" />; }
