import Template from '../kits/music/Template';
export default function Page() { return <Template page="project" basePath="" />; }
