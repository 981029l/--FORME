import Template from '../kits/fashion/Template';
export default function Page() { return <Template page="project" basePath="" />; }
