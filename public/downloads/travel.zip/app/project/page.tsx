import Template from '../kits/travel/Template';
export default function Page() { return <Template page="project" basePath="" />; }
