import Template from '../kits/ceramic/Template';
export default function Page() { return <Template page="about" basePath="" />; }
