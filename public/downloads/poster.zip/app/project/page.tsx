import Template from '../kits/poster/Template';
export default function Page() { return <Template page="project" basePath="" />; }
