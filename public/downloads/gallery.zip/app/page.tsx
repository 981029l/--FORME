import Template from './kits/gallery/Template';
export default function Page() { return <Template page="home" basePath="" />; }
