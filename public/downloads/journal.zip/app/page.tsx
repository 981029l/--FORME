import Template from './kits/journal/Template';
export default function Page() { return <Template page="home" basePath="" />; }
